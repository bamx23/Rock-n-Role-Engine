<div id="l_image">
    Картинко)<br /><br />f
</div>
<div id="l_info">
Инфа о локе
</div>