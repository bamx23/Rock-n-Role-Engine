<b>Настройки</b><br />
<input type="checkbox" class="checkbox" id="s_showloc" alt="Показать/скрыть информацию о локации" /><label for="s_showloc">Информация о локации</label>