<? session_start(); ?>
<? 
header("Request-URI: game.php");
header("Content-Location: game.php");
header("Location: game.php"); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" 
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
        
		<meta http-equiv="content-type" content="text/html; charset=windows-1251" />
		<title>RPGEngine - ����� ����� ��� �������� ������� ���</title>
		<link href="css/style.css" rel="stylesheet" type="text/css" />
        <link href="css/jquery-ui.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="core/jquery.js"></script>
        <script type="text/javascript" src="core/jquery-ui.js"></script>
	</head>
    
	<body>
        <div id="body">
        </div>
        <script type="text/javascript" src="core/core.js"></script>
	</body>
</html>
